<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Leaves;
use Faker\Generator as Faker;

$factory->define(Leaves::class, function (Faker $faker) {
    return [
        //
    ];
});
