<?php if(Auth::user()->type=="employee"): ?>
<?php echo $__env->make('employee.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\leave\resources\views/home.blade.php ENDPATH**/ ?>