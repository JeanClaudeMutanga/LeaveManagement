<?php if(session('errors')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert" id="alert">
            <strong><?php echo e(session('errors')); ?></strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>  
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="container mt-3">
        <div class="alert alert-warning alert-dismissible fade show" role="alert" id="done">
            <strong><?php echo e(session('success')); ?></strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\leave\resources\views/layouts/messages.blade.php ENDPATH**/ ?>